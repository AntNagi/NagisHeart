import { X } from "lucide-react";
import { affectionTitle } from "@/lib/gin/lines";
import type { JournalEntry } from "@/lib/gin/types";
import { cn } from "@/lib/utils";

type JournalSheetProps = {
  open: boolean;
  affection: number;
  entries: JournalEntry[];
  onClose: () => void;
};

export function JournalSheet({ open, affection, entries, onClose }: JournalSheetProps) {
  if (!open) return null;

  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center">
      <button
        type="button"
        aria-label="关闭记录"
        className="absolute inset-0 bg-ink/25"
        onClick={onClose}
      />
      <section
        role="dialog"
        aria-labelledby="journal-title"
        className="relative mb-0 w-full max-w-lg rounded-t-[28px] bg-bg px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4 shadow-[var(--shadow-border)]"
        style={{ animation: "sheet-in 250ms var(--ease-out-smooth) both" }}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-surface-2" />
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="journal-title" className="font-display text-xl font-medium">
              今日
            </h2>
            <p className="mt-1 text-sm text-muted">
              亲密度 {affection}
              <span className="mx-1.5 text-subtle">·</span>
              {affectionTitle(affection)}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="关闭"
            className="grid size-11 place-items-center rounded-full text-muted transition-[background-color,scale] duration-150 ease-out hover:bg-surface hover:text-fg active:scale-[0.96]"
          >
            <X className="size-4" />
          </button>
        </div>

        <ul className="mt-4 max-h-[min(52vh,28rem)] space-y-1 overflow-y-auto pr-1">
          {entries.length === 0 ? (
            <li className="rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted">
              还没发生什么。点他一下。
            </li>
          ) : (
            entries.map((e) => (
              <li
                key={e.id}
                className={cn(
                  "flex items-baseline justify-between gap-3 rounded-xl px-3 py-2.5",
                  "bg-surface/70",
                )}
              >
                <span className="text-sm text-fg">{e.note}</span>
                <time className="shrink-0 text-xs tabular-nums text-subtle">
                  {formatTime(e.at)}
                </time>
              </li>
            ))
          )}
        </ul>
      </section>
    </div>
  );
}

function formatTime(at: number) {
  const d = new Date(at);
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${h}:${m}`;
}
