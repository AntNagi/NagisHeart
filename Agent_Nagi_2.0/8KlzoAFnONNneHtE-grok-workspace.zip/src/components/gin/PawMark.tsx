import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

type PawMarkProps = {
  className?: string;
  title?: string;
  style?: CSSProperties;
};

export function PawMark({ className, title, style }: PawMarkProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden={title ? undefined : true}
      className={cn("block", className)}
      style={style}
    >
      {title ? <title>{title}</title> : null}
      <circle cx="7.2" cy="8.2" r="2.15" />
      <circle cx="11.6" cy="6.1" r="2.05" />
      <circle cx="16.2" cy="7.6" r="2.1" />
      <circle cx="18.4" cy="11.8" r="1.85" />
      <ellipse cx="11.4" cy="16.2" rx="5.1" ry="4.2" />
    </svg>
  );
}
