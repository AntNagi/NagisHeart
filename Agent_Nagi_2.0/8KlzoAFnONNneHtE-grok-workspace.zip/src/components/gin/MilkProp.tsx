export function MilkProp() {
  return (
    <div className="milk-arc pointer-events-none absolute bottom-[20%] left-[14%] z-20 origin-bottom">
      <svg width="52" height="70" viewBox="0 0 44 58" fill="none" aria-hidden>
        <path
          d="M10 16h24l3 38H7L10 16Z"
          className="fill-bubble stroke-ink"
          strokeWidth="1.4"
        />
        <path d="M10 16l2-8h20l2 8" className="fill-surface-2 stroke-ink" strokeWidth="1.4" />
        <rect x="16" y="4" width="12" height="6" rx="1.5" className="fill-accent" />
        <rect x="14" y="24" width="16" height="16" rx="2" className="fill-heart" />
        <circle cx="22" cy="32" r="4.2" className="fill-bubble" />
        <path
          d="M20.2 33.6c0-1.4.8-2.4 1.8-2.4s1.8 1 1.8 2.4"
          className="stroke-heart"
          strokeWidth="1.2"
          fill="none"
        />
      </svg>
    </div>
  );
}