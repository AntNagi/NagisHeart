import { useCallback, useEffect, useRef, useState } from "react";
import {
  greetingForHour,
  lineForAction,
  lineForAnnoyed,
  lineForIdle,
  lineForWake,
  lineForZone,
} from "@/lib/gin/lines";
import {
  playCat,
  playFeed,
  playPet,
  playSleep,
  playTap,
  playWake,
  unlockAudio,
} from "@/lib/gin/sound";
import { useGinStore } from "@/lib/gin/store";
import { HIT_ZONES, type ActionId, type Particle, type Speech, type ZoneId } from "@/lib/gin/types";
import { cn } from "@/lib/utils";
import { ActionDock } from "./ActionDock";
import { JournalSheet } from "./JournalSheet";
import { MilkProp } from "./MilkProp";
import { Particles } from "./Particles";
import { PawMark } from "./PawMark";
import { SpeechBubble } from "./SpeechBubble";
import { TopBar } from "./TopBar";

function formatHm(d: Date) {
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${h}:${m}`;
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function zoneAt(xPct: number, yPct: number): ZoneId {
  const hit = HIT_ZONES.find(
    (z) =>
      xPct >= z.left &&
      xPct <= z.left + z.width &&
      yPct >= z.top &&
      yPct <= z.top + z.height,
  );
  return hit?.id ?? "body";
}

function speechAnchor(zone: ZoneId, from: "gin" | "cat"): { x: number; y: number } {
  if (from === "cat" || zone === "cat") return { x: 36, y: 50 };
  if (zone === "feet") return { x: 72, y: 20 };
  if (zone === "legs") return { x: 58, y: 26 };
  if (zone === "phone") return { x: 16, y: 20 };
  return { x: 22, y: 16 };
}

export function CompanionStage() {
  const affection = useGinStore((s) => s.affection);
  const sleeping = useGinStore((s) => s.sleeping);
  const muted = useGinStore((s) => s.muted);
  const mood = useGinStore((s) => s.mood);
  const journal = useGinStore((s) => s.journal);
  const bumpAffection = useGinStore((s) => s.bumpAffection);
  const setMood = useGinStore((s) => s.setMood);
  const setSleeping = useGinStore((s) => s.setSleeping);
  const toggleMuted = useGinStore((s) => s.toggleMuted);
  const record = useGinStore((s) => s.record);
  const bumpStreak = useGinStore((s) => s.bumpStreak);

  const figureRef = useRef<HTMLDivElement>(null);
  const greeted = useRef(false);
  const idleTimer = useRef<number | null>(null);

  const [pose, setPose] = useState<"idle" | "react" | "eating">("idle");
  const [origin, setOrigin] = useState("44% 82%");
  const [speech, setSpeech] = useState<Speech | null>(null);
  const [leaving, setLeaving] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [showMilk, setShowMilk] = useState(false);
  const [hint, setHint] = useState(true);
  const [journalOpen, setJournalOpen] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  const [blush, setBlush] = useState(false);

  const timeLabel = now ? formatHm(now) : "--:--";

  const speak = useCallback((text: string, from: "gin" | "cat", zone: ZoneId = "head") => {
    const anchor = speechAnchor(zone, from);
    setLeaving(false);
    setSpeech({ id: uid(), text, from, x: anchor.x, y: anchor.y });
  }, []);

  const burst = useCallback((kind: Particle["kind"], x: number, y: number, count = 3) => {
    const next: Particle[] = Array.from({ length: count }, (_, i) => ({
      id: uid() + i,
      kind,
      x: x + (Math.random() * 8 - 4),
      y: y + (Math.random() * 6 - 3),
      delay: i * 70,
    }));
    setParticles((prev) => [...prev, ...next]);
    window.setTimeout(() => {
      setParticles((prev) => prev.filter((p) => !next.some((n) => n.id === p.id)));
    }, 1100);
  }, []);

  const poke = useCallback(() => {
    setPose("react");
    window.setTimeout(() => setPose("idle"), 620);
  }, []);

  const resetIdle = useCallback(() => {
    if (idleTimer.current) window.clearTimeout(idleTimer.current);
    idleTimer.current = window.setTimeout(() => {
      if (useGinStore.getState().sleeping) return;
      speak(lineForIdle(), "gin", "head");
    }, 18000);
  }, [speak]);

  const log = useCallback(
    (kind: ZoneId | ActionId | "wake") => {
      setHint(false);
      resetIdle();
      record(kind);
    },
    [record, resetIdle],
  );

  const onFigurePointer = useCallback(
    (clientX: number, clientY: number) => {
      const el = figureRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const xPct = ((clientX - rect.left) / rect.width) * 100;
      const yPct = ((clientY - rect.top) / rect.height) * 100;
      setOrigin(`${xPct}% ${yPct}%`);

      const state = useGinStore.getState();
      if (state.sleeping) {
        if (!state.muted) playWake();
        setSleeping(false);
        speak(lineForWake(), "gin", "head");
        burst("paw", xPct, yPct, 2);
        poke();
        log("wake");
        return;
      }

      const zone = zoneAt(xPct, yPct);
      const streak = bumpStreak();
      const annoyed = streak >= 5;
      const line = annoyed ? { text: lineForAnnoyed(), from: "gin" as const } : lineForZone(zone);

      if (!state.muted) {
        if (zone === "cat") playCat();
        else playTap();
      }

      speak(line.text, line.from, zone);
      poke();
      burst(zone === "cat" ? "paw" : annoyed ? "paw" : "heart", xPct, yPct, annoyed ? 2 : 3);
      bumpAffection(annoyed ? 0 : zone === "cat" ? 2 : 1);
      setMood(annoyed ? "annoyed" : zone === "cat" ? "happy" : "idle");
      setBlush(zone === "head" || zone === "body");
      window.setTimeout(() => setBlush(false), 900);
      log(zone);
    },
    [bumpAffection, bumpStreak, burst, log, poke, setMood, setSleeping, speak],
  );

  const onAction = useCallback(
    (id: ActionId) => {
      unlockAudio();
      const state = useGinStore.getState();

      if (id === "nap") {
        if (state.sleeping) {
          if (!state.muted) playWake();
          setSleeping(false);
          speak(lineForWake(), "gin", "head");
          log("wake");
          poke();
          return;
        }
        if (!state.muted) playSleep();
        setSleeping(true);
        speak(lineForAction("nap"), "gin", "head");
        burst("z", 28, 16, 3);
        log("nap");
        return;
      }

      if (state.sleeping) {
        if (!state.muted) playWake();
        setSleeping(false);
        speak(lineForWake(), "gin", "head");
        log("wake");
      }

      if (id === "pet") {
        if (!useGinStore.getState().muted) playPet();
        speak(lineForAction("pet"), "gin", "head");
        poke();
        burst("heart", 26, 22, 5);
        bumpAffection(2);
        setMood("happy");
        setBlush(true);
        window.setTimeout(() => setBlush(false), 1100);
        log("pet");
        return;
      }

      if (id === "feed") {
        if (!useGinStore.getState().muted) playFeed();
        setShowMilk(true);
        setPose("eating");
        setMood("eating");
        speak(lineForAction("feed"), "gin", "phone");
        bumpAffection(3);
        window.setTimeout(() => {
          setShowMilk(false);
          setPose("idle");
          setMood("happy");
        }, 1000);
        log("feed");
        return;
      }

      speak(lineForAction("talk"), "gin", "head");
      poke();
      bumpAffection(1);
      setMood("idle");
      log("talk");
    },
    [bumpAffection, burst, log, poke, setMood, setSleeping, speak],
  );

  useEffect(() => {
    setNow(new Date());
    const tick = window.setInterval(() => setNow(new Date()), 30000);
    return () => window.clearInterval(tick);
  }, []);

  useEffect(() => {
    if (greeted.current) return;
    greeted.current = true;
    const hour = new Date().getHours();
    const t = window.setTimeout(() => {
      if (useGinStore.getState().sleeping) return;
      speak(greetingForHour(hour), "gin", "head");
    }, 700);
    resetIdle();
    return () => {
      window.clearTimeout(t);
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
    };
  }, [resetIdle, speak]);

  useEffect(() => {
    if (!speech) return;
    const t = window.setTimeout(() => setLeaving(true), 2400);
    const t2 = window.setTimeout(() => {
      setSpeech(null);
      setLeaving(false);
    }, 2580);
    return () => {
      window.clearTimeout(t);
      window.clearTimeout(t2);
    };
  }, [speech]);

  const hour = now?.getHours() ?? 12;
  const dusk = sleeping || hour >= 22 || hour < 6;

  return (
    <div className="relative flex min-h-[100dvh] flex-col overflow-hidden bg-bg text-fg">
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-700 ease-[var(--ease-out-smooth)]"
        style={{
          opacity: dusk ? 1 : 0,
          background:
            "linear-gradient(180deg, color-mix(in oklab, var(--color-ink) 10%, var(--color-dusk)) 0%, var(--color-bg-warm) 100%)",
        }}
        aria-hidden
      />

      <AmbientPaws />

      <div className="relative z-10 flex min-h-[100dvh] flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
        <TopBar
          timeLabel={timeLabel}
          mood={mood}
          sleeping={sleeping}
          affection={affection}
          muted={muted}
          onToggleMute={() => {
            unlockAudio();
            toggleMuted();
          }}
          onOpenJournal={() => setJournalOpen(true)}
        />

        <div className="relative flex min-h-0 flex-1 flex-col items-center justify-center">
          <div className="relative w-full max-w-5xl overflow-hidden">
            <div
              ref={figureRef}
              className={cn(
                "gin-figure relative mx-auto select-none",
                sleeping && "is-sleeping",
                pose === "react" && "is-reacting",
                pose === "eating" && "is-eating",
              )}
              style={{ transformOrigin: origin }}
            >
              <button
                type="button"
                aria-label="银，点一下他会理你"
                className="block w-full cursor-pointer touch-manipulation border-0 bg-transparent p-0"
                onPointerDown={(e) => {
                  if (e.button !== 0 && e.pointerType === "mouse") return;
                  onFigurePointer(e.clientX, e.clientY);
                }}
              >
                <img
                  src="/gin.webp"
                  alt="银趴在那里看手机，一只狸花猫靠在他手臂上"
                  draggable={false}
                  className="ml-0 h-auto w-[min(178vw,72rem)] max-w-none max-h-[min(56vh,520px)] object-contain object-left sm:mx-auto sm:w-full sm:max-w-full sm:max-h-[min(68vh,720px)] sm:object-center"
                />
              </button>

              {blush && !sleeping ? (
                <div className="pointer-events-none absolute inset-0" aria-hidden>
                  <span className="absolute top-[30%] left-[17%] size-8 rounded-full bg-heart/45 blur-[7px] sm:size-10" />
                  <span className="absolute top-[31%] left-[23%] size-7 rounded-full bg-heart/30 blur-[7px] sm:size-9" />
                </div>
              ) : null}

              {sleeping ? (
                <>
                  <span className="z-rise pointer-events-none absolute top-[8%] left-[26%] font-display text-xl text-muted">
                    Z
                  </span>
                  <span
                    className="z-rise pointer-events-none absolute top-[4%] left-[31%] font-display text-lg text-subtle"
                    style={{ animationDelay: "0.6s" }}
                  >
                    z
                  </span>
                </>
              ) : null}

              {showMilk ? <MilkProp /> : null}
              {speech ? <SpeechBubble speech={speech} leaving={leaving} /> : null}
              <Particles items={particles} />
            </div>

            <div
              className="gin-shadow mx-auto -mt-2 h-5 w-[70%] max-w-xl rounded-[100%] bg-ink/20 blur-md"
              aria-hidden
            />

            <p
              className={cn(
                "mt-5 h-5 text-center text-sm text-muted",
                hint ? "hint-pulse" : "invisible",
              )}
            >
              点一点他
            </p>
          </div>
        </div>

        <div className="relative z-10 mt-2 w-full pb-1">
          <ActionDock sleeping={sleeping} onAction={onAction} />
        </div>
      </div>

      <JournalSheet
        open={journalOpen}
        affection={affection}
        entries={journal}
        onClose={() => setJournalOpen(false)}
      />
    </div>
  );
}

function AmbientPaws() {
  const spots = [
    { top: "18%", left: "72%", size: 28, delay: "0s" },
    { top: "32%", left: "82%", size: 22, delay: "1.4s" },
    { top: "48%", left: "76%", size: 18, delay: "2.6s" },
    { top: "22%", left: "8%", size: 16, delay: "3.2s" },
  ];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {spots.map((s, i) => (
        <PawMark
          key={i}
          className="paw-drift absolute text-paw"
          style={{
            top: s.top,
            left: s.left,
            width: s.size,
            height: s.size,
            animationDelay: s.delay,
          }}
        />
      ))}
    </div>
  );
}
