import { Hand, MessageCircle, Moon, CupSoda } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ActionId } from "@/lib/gin/types";

const ACTIONS: { id: ActionId; label: string; Icon: typeof Hand }[] = [
  { id: "pet", label: "摸摸", Icon: Hand },
  { id: "feed", label: "投喂", Icon: CupSoda },
  { id: "talk", label: "说话", Icon: MessageCircle },
  { id: "nap", label: "小憩", Icon: Moon },
];

type ActionDockProps = {
  sleeping: boolean;
  onAction: (id: ActionId) => void;
};

export function ActionDock({ sleeping, onAction }: ActionDockProps) {
  return (
    <nav
      aria-label="相处"
      className="pointer-events-auto mx-auto flex w-full max-w-md items-stretch gap-1 rounded-3xl bg-surface/90 p-1.5 shadow-[var(--shadow-border)] backdrop-blur-sm"
    >
      {ACTIONS.map(({ id, label, Icon }) => {
        const napActive = sleeping && id === "nap";
        return (
          <button
            key={id}
            type="button"
            onClick={() => onAction(id)}
            className={cn(
              "flex min-h-12 flex-1 flex-col items-center justify-center gap-0.5 rounded-2xl px-2 py-2 text-muted",
              "transition-[background-color,color,scale] duration-150 ease-out",
              "hover:bg-bg hover:text-fg active:scale-[0.96]",
              napActive && "bg-bg text-fg",
            )}
          >
            <Icon className="size-4" strokeWidth={1.75} aria-hidden />
            <span className="text-xs font-medium tracking-wide">{napActive ? "叫醒" : label}</span>
          </button>
        );
      })}
    </nav>
  );
}
