import { PawMark } from "./PawMark";
import type { Particle } from "@/lib/gin/types";

type ParticlesProps = {
  items: Particle[];
};

export function Particles({ items }: ParticlesProps) {
  return (
    <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">
      {items.map((p) => (
        <span
          key={p.id}
          className="absolute"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            animation: `particle-float 980ms var(--ease-out-smooth) ${p.delay}ms both`,
            ["--dx" as string]: `${(p.id.charCodeAt(0) % 17) - 8}px`,
            ["--spin" as string]: `${(p.id.charCodeAt(3) % 24) - 12}deg`,
          }}
        >
          {p.kind === "heart" ? (
            <HeartMark className="size-5 text-heart" />
          ) : p.kind === "z" ? (
            <span className="font-display text-lg font-medium text-muted">Z</span>
          ) : (
            <PawMark className="size-5 text-paw" />
          )}
        </span>
      ))}
    </div>
  );
}

function HeartMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M12.1 20.3c-.3 0-.5-.1-1.6-1.1-3.3-2.9-6.5-5.6-6.5-9 0-2.4 1.9-4.3 4.3-4.3 1.4 0 2.7.7 3.8 1.9 1.1-1.2 2.4-1.9 3.8-1.9 2.4 0 4.3 1.9 4.3 4.3 0 3.4-3.2 6.1-6.5 9-1.1 1-1.3 1.1-1.6 1.1Z" />
    </svg>
  );
}
