import type { ReactNode } from "react";
import { BookOpen, Download, Volume2, VolumeX } from "lucide-react";
import { affectionTitle, moodLabel } from "@/lib/gin/lines";
import type { Mood } from "@/lib/gin/types";
import { cn } from "@/lib/utils";

type TopBarProps = {
  timeLabel: string;
  mood: Mood;
  sleeping: boolean;
  affection: number;
  muted: boolean;
  onToggleMute: () => void;
  onOpenJournal: () => void;
};

export function TopBar({
  timeLabel,
  mood,
  sleeping,
  affection,
  muted,
  onToggleMute,
  onOpenJournal,
}: TopBarProps) {
  return (
    <header className="pointer-events-none flex items-start justify-between gap-4 px-1">
      <div className="pointer-events-none min-w-0">
        <p className="font-display text-3xl font-medium leading-none tracking-tight text-fg">
          银
        </p>
        <p className="mt-1.5 text-xs font-medium tracking-wide text-muted">
          {moodLabel(mood, sleeping)}
          <span className="mx-1.5 text-subtle">·</span>
          {affectionTitle(affection)}
        </p>
        <div
          className="mt-2.5 h-0.5 w-28 overflow-hidden rounded-full bg-surface-2"
          aria-label={`亲密度 ${affection}`}
        >
          <div
            className="h-full rounded-full bg-accent transition-[width] duration-500 ease-[var(--ease-out-smooth)]"
            style={{ width: `${affection}%` }}
          />
        </div>
      </div>

      <div className="pointer-events-auto flex items-center gap-1">
        <span className="mr-1 hidden font-display text-sm tabular-nums text-muted sm:inline">{timeLabel}</span>
        <a
          href="/yin-companion.zip"
          download="yin-companion.zip"
          className={cn(
            "mr-1 inline-flex h-11 items-center gap-1.5 rounded-full bg-ink px-3.5 text-xs font-medium tracking-wide text-accent-fg",
            "transition-[scale,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96]",
          )}
        >
          <Download className="size-3.5" strokeWidth={2} aria-hidden />
          下载源码
        </a>
        <IconBtn
          label={muted ? "打开声音" : "关闭声音"}
          onClick={onToggleMute}
        >
          {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </IconBtn>
        <IconBtn label="今日记录" onClick={onOpenJournal}>
          <BookOpen className="size-4" />
        </IconBtn>
      </div>
    </header>
  );
}

function IconBtn({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={cn(
        "grid size-11 place-items-center rounded-full text-muted",
        "transition-[background-color,color,scale] duration-150 ease-out",
        "hover:bg-surface hover:text-fg active:scale-[0.96]",
      )}
    >
      {children}
    </button>
  );
}
