import { cn } from "@/lib/utils";
import type { Speech } from "@/lib/gin/types";

type SpeechBubbleProps = {
  speech: Speech;
  leaving?: boolean;
};

export function SpeechBubble({ speech, leaving }: SpeechBubbleProps) {
  const isCat = speech.from === "cat";
  return (
    <div
      className={cn(
        "pointer-events-none absolute z-20 max-w-[min(16rem,70vw)]",
        leaving ? "speech-leave" : "speech-enter",
      )}
      style={{
        left: `${speech.x}%`,
        top: `${speech.y}%`,
        transform: "translate(-30%, -110%)",
      }}
      role="status"
    >
      <div
        className={cn(
          "relative rounded-2xl px-3.5 py-2.5 text-sm leading-snug shadow-[var(--shadow-border)]",
          isCat
            ? "bg-surface-2 text-muted"
            : "bg-bubble text-fg",
        )}
      >
        <p className={cn("font-medium", isCat && "text-xs tracking-wide")}>
          {speech.text}
        </p>
        <span
          className={cn(
            "absolute -bottom-1.5 left-6 size-3 rotate-45 rounded-sm",
            isCat ? "bg-surface-2" : "bg-bubble",
          )}
          aria-hidden
        />
      </div>
    </div>
  );
}
