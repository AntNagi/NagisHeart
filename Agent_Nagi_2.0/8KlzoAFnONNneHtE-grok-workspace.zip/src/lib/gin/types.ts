export type ZoneId = "head" | "phone" | "cat" | "body" | "legs" | "feet";

export type ActionId = "pet" | "feed" | "talk" | "nap";

export type Mood = "idle" | "happy" | "annoyed" | "sleepy" | "eating";

export type JournalKind = ZoneId | ActionId | "wake";

export type JournalEntry = {
  id: string;
  at: number;
  kind: JournalKind;
  note: string;
};

export type Speech = {
  id: string;
  text: string;
  from: "gin" | "cat";
  x: number;
  y: number;
};

export type Particle = {
  id: string;
  kind: "paw" | "heart" | "z";
  x: number;
  y: number;
  delay: number;
};

export type HitZone = {
  id: ZoneId;
  label: string;
  left: number;
  top: number;
  width: number;
  height: number;
};

export const HIT_ZONES: HitZone[] = [
  { id: "phone", label: "手机", left: 0.5, top: 30, width: 13, height: 30 },
  { id: "head", label: "头发", left: 11, top: 3, width: 18, height: 38 },
  { id: "cat", label: "猫", left: 21, top: 48, width: 23, height: 36 },
  { id: "body", label: "后背", left: 30, top: 22, width: 28, height: 40 },
  { id: "legs", label: "腿", left: 56, top: 30, width: 24, height: 36 },
  { id: "feet", label: "脚", left: 79, top: 14, width: 20, height: 38 },
];
