type Tone = {
  freq: number;
  dur: number;
  type?: OscillatorType;
  gain?: number;
  slide?: number;
};

let ctx: AudioContext | null = null;
let unlocked = false;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
  }
  return ctx;
}

export function unlockAudio() {
  const audio = getCtx();
  if (!audio) return;
  if (audio.state === "suspended") void audio.resume();
  unlocked = true;
}

function playTones(tones: Tone[]) {
  const audio = getCtx();
  if (!audio || !unlocked) return;
  if (audio.state === "suspended") void audio.resume();
  const now = audio.currentTime;
  for (const tone of tones) {
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = tone.type ?? "sine";
    osc.frequency.setValueAtTime(tone.freq, now);
    if (tone.slide) {
      osc.frequency.linearRampToValueAtTime(tone.freq + tone.slide, now + tone.dur);
    }
    const g = tone.gain ?? 0.05;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(g, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + tone.dur);
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start(now);
    osc.stop(now + tone.dur + 0.02);
  }
}

export function playTap() {
  playTones([{ freq: 420, dur: 0.08, type: "triangle", gain: 0.04 }]);
}

export function playPet() {
  playTones([
    { freq: 520, dur: 0.12, type: "sine", gain: 0.045 },
    { freq: 780, dur: 0.16, type: "sine", gain: 0.03, slide: 40 },
  ]);
}

export function playFeed() {
  playTones([
    { freq: 330, dur: 0.1, type: "triangle", gain: 0.04 },
    { freq: 494, dur: 0.14, type: "sine", gain: 0.035, slide: 20 },
  ]);
}

export function playSleep() {
  playTones([{ freq: 180, dur: 0.28, type: "sine", gain: 0.035, slide: -40 }]);
}

export function playWake() {
  playTones([{ freq: 360, dur: 0.12, type: "triangle", gain: 0.04, slide: 80 }]);
}

export function playCat() {
  playTones([
    { freq: 640, dur: 0.09, type: "sine", gain: 0.03, slide: 70 },
    { freq: 720, dur: 0.11, type: "triangle", gain: 0.025, slide: -30 },
  ]);
}
