import type { ActionId, Mood, ZoneId } from "./types";

function pick<T>(list: T[]): T {
  return list[Math.floor(Math.random() * list.length)]!;
}

const ZONE_LINES: Record<ZoneId, string[]> = {
  head: [
    "看什么看。",
    "……有事？",
    "刘海别乱戳。",
    "手拿开。",
    "很闲吗。",
  ],
  phone: [
    "少管闲事。",
    "在看很重要的东西。",
    "别挡屏幕。",
    "……更新了。",
    "自己去刷。",
  ],
  cat: [
    "它在睡觉。",
    "轻一点。",
    "挺会挑地方。",
    "别把它弄醒。",
    "……它先来的。",
  ],
  body: [
    "摸什么摸。",
    "手感一般。",
    "……随你。",
    "背后很凉，别一直捂。",
    "衣服皱了。",
  ],
  legs: [
    "腿不是靠垫。",
    "自己找地方坐。",
    "……懒得踢你。",
    "别压着。",
  ],
  feet: [
    "喂。",
    "别碰。",
    "有完没完。",
    "脚很干净，谢谢。",
  ],
};

const CAT_LINES = ["……", "唔。", "……嗯。", "。"];

const PET_LINES = [
  "……还行。",
  "再这样我可要收费了。",
  "嗯。",
  "手倒是不冰。",
  "……随你摸。",
];

const FEED_LINES = [
  "草莓牛奶？",
  "再来一盒。",
  "……谢了。",
  "冷藏的吧。",
  "不算讨厌。",
];

const TALK_LINES = [
  "今天也没什么干劲。",
  "你还在啊。",
  "无聊的时候就来戳我？",
  "……随便待着。",
  "我又没赶你。",
  "天气预报看了，还是躺着吧。",
  "猫比人省心。",
];

const NAP_LINES = ["……呼。", "别吵。", "眼皮打架了。"];

const WAKE_LINES = ["……几点了。", "还没睡够。", "谁。"];

const IDLE_LINES = ["……", "还在？", "随便。", "嗯。"];

const ANNOYED_LINES = ["有完没完啊。", "手停一下。", "……够了。"];

export function lineForZone(zone: ZoneId): { text: string; from: "gin" | "cat" } {
  if (zone === "cat" && Math.random() < 0.45) {
    return { text: pick(CAT_LINES), from: "cat" };
  }
  return { text: pick(ZONE_LINES[zone]), from: "gin" };
}

export function lineForAction(action: ActionId): string {
  switch (action) {
    case "pet":
      return pick(PET_LINES);
    case "feed":
      return pick(FEED_LINES);
    case "talk":
      return pick(TALK_LINES);
    case "nap":
      return pick(NAP_LINES);
  }
}

export function lineForWake(): string {
  return pick(WAKE_LINES);
}

export function lineForIdle(): string {
  return pick(IDLE_LINES);
}

export function lineForAnnoyed(): string {
  return pick(ANNOYED_LINES);
}

export function greetingForHour(hour: number): string {
  if (hour >= 5 && hour < 11) return "这么早。";
  if (hour >= 11 && hour < 14) return "午饭了？";
  if (hour >= 14 && hour < 18) return "下午没什么事。";
  if (hour >= 18 && hour < 22) return "还没走。";
  return "……睡吧。";
}

export function moodLabel(mood: Mood, sleeping: boolean): string {
  if (sleeping) return "睡着了";
  switch (mood) {
    case "happy":
      return "还不错";
    case "annoyed":
      return "有点烦";
    case "sleepy":
      return "犯困";
    case "eating":
      return "在喝";
    default:
      return "躺着";
  }
}

export function affectionTitle(value: number): string {
  if (value >= 80) return "家里人";
  if (value >= 60) return "能待一起";
  if (value >= 40) return "还算熟";
  if (value >= 20) return "认识了";
  return "路人";
}

export function journalNote(kind: ZoneId | ActionId | "wake"): string {
  switch (kind) {
    case "head":
      return "戳了头发";
    case "phone":
      return "偷看了屏幕";
    case "cat":
      return "摸了猫";
    case "body":
      return "拍了后背";
    case "legs":
      return "碰了腿";
    case "feet":
      return "碰了脚";
    case "pet":
      return "好好摸了摸";
    case "feed":
      return "投喂了草莓牛奶";
    case "talk":
      return "说了两句";
    case "nap":
      return "让他睡一会儿";
    case "wake":
      return "把他叫醒了";
  }
}
