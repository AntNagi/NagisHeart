import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ActionId, JournalEntry, Mood, ZoneId } from "./types";
import { journalNote } from "./lines";

const MAX_JOURNAL = 28;

type GinState = {
  affection: number;
  sleeping: boolean;
  muted: boolean;
  mood: Mood;
  journal: JournalEntry[];
  tapStreak: number;
  lastTapAt: number;
  bumpAffection: (delta: number) => void;
  setMood: (mood: Mood) => void;
  setSleeping: (value: boolean) => void;
  toggleMuted: () => void;
  record: (kind: ZoneId | ActionId | "wake") => void;
  bumpStreak: () => number;
  resetStreak: () => void;
};

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export const useGinStore = create<GinState>()(
  persist(
    (set, get) => ({
      affection: 8,
      sleeping: false,
      muted: false,
      mood: "idle",
      journal: [],
      tapStreak: 0,
      lastTapAt: 0,
      bumpAffection: (delta) =>
        set({ affection: clamp(get().affection + delta, 0, 100) }),
      setMood: (mood) => set({ mood }),
      setSleeping: (value) => set({ sleeping: value, mood: value ? "sleepy" : "idle" }),
      toggleMuted: () => set({ muted: !get().muted }),
      record: (kind) => {
        const entry: JournalEntry = {
          id: uid(),
          at: Date.now(),
          kind,
          note: journalNote(kind),
        };
        set({ journal: [entry, ...get().journal].slice(0, MAX_JOURNAL) });
      },
      bumpStreak: () => {
        const now = Date.now();
        const prev = get().lastTapAt;
        const next = now - prev < 900 ? get().tapStreak + 1 : 1;
        set({ tapStreak: next, lastTapAt: now });
        return next;
      },
      resetStreak: () => set({ tapStreak: 0 }),
    }),
    {
      name: "gin-home-v1",
      partialize: (s) => ({
        affection: s.affection,
        muted: s.muted,
        journal: s.journal,
      }),
    },
  ),
);
