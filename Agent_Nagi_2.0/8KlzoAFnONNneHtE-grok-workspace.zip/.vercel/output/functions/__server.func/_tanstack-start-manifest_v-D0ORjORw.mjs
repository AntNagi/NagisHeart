//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D0ORjORw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-RORMzhVz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-RORMzhVz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dp3jQ_Zl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
