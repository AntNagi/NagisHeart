import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Moon, c as CupSoda, l as BookOpen, n as VolumeX, o as MessageCircle, r as Volume2, s as Hand, t as X } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-NSiWL7Sd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function pick(list) {
	return list[Math.floor(Math.random() * list.length)];
}
var ZONE_LINES = {
	head: [
		"看什么看。",
		"……有事？",
		"刘海别乱戳。",
		"手拿开。",
		"很闲吗。"
	],
	phone: [
		"少管闲事。",
		"在看很重要的东西。",
		"别挡屏幕。",
		"……更新了。",
		"自己去刷。"
	],
	cat: [
		"它在睡觉。",
		"轻一点。",
		"挺会挑地方。",
		"别把它弄醒。",
		"……它先来的。"
	],
	body: [
		"摸什么摸。",
		"手感一般。",
		"……随你。",
		"背后很凉，别一直捂。",
		"衣服皱了。"
	],
	legs: [
		"腿不是靠垫。",
		"自己找地方坐。",
		"……懒得踢你。",
		"别压着。"
	],
	feet: [
		"喂。",
		"别碰。",
		"有完没完。",
		"脚很干净，谢谢。"
	]
};
var CAT_LINES = [
	"……",
	"唔。",
	"……嗯。",
	"。"
];
var PET_LINES = [
	"……还行。",
	"再这样我可要收费了。",
	"嗯。",
	"手倒是不冰。",
	"……随你摸。"
];
var FEED_LINES = [
	"草莓牛奶？",
	"再来一盒。",
	"……谢了。",
	"冷藏的吧。",
	"不算讨厌。"
];
var TALK_LINES = [
	"今天也没什么干劲。",
	"你还在啊。",
	"无聊的时候就来戳我？",
	"……随便待着。",
	"我又没赶你。",
	"天气预报看了，还是躺着吧。",
	"猫比人省心。"
];
var NAP_LINES = [
	"……呼。",
	"别吵。",
	"眼皮打架了。"
];
var WAKE_LINES = [
	"……几点了。",
	"还没睡够。",
	"谁。"
];
var IDLE_LINES = [
	"……",
	"还在？",
	"随便。",
	"嗯。"
];
var ANNOYED_LINES = [
	"有完没完啊。",
	"手停一下。",
	"……够了。"
];
function lineForZone(zone) {
	if (zone === "cat" && Math.random() < .45) return {
		text: pick(CAT_LINES),
		from: "cat"
	};
	return {
		text: pick(ZONE_LINES[zone]),
		from: "gin"
	};
}
function lineForAction(action) {
	switch (action) {
		case "pet": return pick(PET_LINES);
		case "feed": return pick(FEED_LINES);
		case "talk": return pick(TALK_LINES);
		case "nap": return pick(NAP_LINES);
	}
}
function lineForWake() {
	return pick(WAKE_LINES);
}
function lineForIdle() {
	return pick(IDLE_LINES);
}
function lineForAnnoyed() {
	return pick(ANNOYED_LINES);
}
function greetingForHour(hour) {
	if (hour >= 5 && hour < 11) return "这么早。";
	if (hour >= 11 && hour < 14) return "午饭了？";
	if (hour >= 14 && hour < 18) return "下午没什么事。";
	if (hour >= 18 && hour < 22) return "还没走。";
	return "……睡吧。";
}
function moodLabel(mood, sleeping) {
	if (sleeping) return "睡着了";
	switch (mood) {
		case "happy": return "还不错";
		case "annoyed": return "有点烦";
		case "sleepy": return "犯困";
		case "eating": return "在喝";
		default: return "躺着";
	}
}
function affectionTitle(value) {
	if (value >= 80) return "家里人";
	if (value >= 60) return "能待一起";
	if (value >= 40) return "还算熟";
	if (value >= 20) return "认识了";
	return "路人";
}
function journalNote(kind) {
	switch (kind) {
		case "head": return "戳了头发";
		case "phone": return "偷看了屏幕";
		case "cat": return "摸了猫";
		case "body": return "拍了后背";
		case "legs": return "碰了腿";
		case "feet": return "碰了脚";
		case "pet": return "好好摸了摸";
		case "feed": return "投喂了草莓牛奶";
		case "talk": return "说了两句";
		case "nap": return "让他睡一会儿";
		case "wake": return "把他叫醒了";
	}
}
var ctx = null;
var unlocked = false;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor();
	}
	return ctx;
}
function unlockAudio() {
	const audio = getCtx();
	if (!audio) return;
	if (audio.state === "suspended") audio.resume();
	unlocked = true;
}
function playTones(tones) {
	const audio = getCtx();
	if (!audio || !unlocked) return;
	if (audio.state === "suspended") audio.resume();
	const now = audio.currentTime;
	for (const tone of tones) {
		const osc = audio.createOscillator();
		const gain = audio.createGain();
		osc.type = tone.type ?? "sine";
		osc.frequency.setValueAtTime(tone.freq, now);
		if (tone.slide) osc.frequency.linearRampToValueAtTime(tone.freq + tone.slide, now + tone.dur);
		const g = tone.gain ?? .05;
		gain.gain.setValueAtTime(0, now);
		gain.gain.linearRampToValueAtTime(g, now + .012);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + tone.dur);
		osc.connect(gain);
		gain.connect(audio.destination);
		osc.start(now);
		osc.stop(now + tone.dur + .02);
	}
}
function playTap() {
	playTones([{
		freq: 420,
		dur: .08,
		type: "triangle",
		gain: .04
	}]);
}
function playPet() {
	playTones([{
		freq: 520,
		dur: .12,
		type: "sine",
		gain: .045
	}, {
		freq: 780,
		dur: .16,
		type: "sine",
		gain: .03,
		slide: 40
	}]);
}
function playFeed() {
	playTones([{
		freq: 330,
		dur: .1,
		type: "triangle",
		gain: .04
	}, {
		freq: 494,
		dur: .14,
		type: "sine",
		gain: .035,
		slide: 20
	}]);
}
function playSleep() {
	playTones([{
		freq: 180,
		dur: .28,
		type: "sine",
		gain: .035,
		slide: -40
	}]);
}
function playWake() {
	playTones([{
		freq: 360,
		dur: .12,
		type: "triangle",
		gain: .04,
		slide: 80
	}]);
}
function playCat() {
	playTones([{
		freq: 640,
		dur: .09,
		type: "sine",
		gain: .03,
		slide: 70
	}, {
		freq: 720,
		dur: .11,
		type: "triangle",
		gain: .025,
		slide: -30
	}]);
}
var MAX_JOURNAL = 28;
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function uid$1() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
var useGinStore = create()(persist((set, get) => ({
	affection: 8,
	sleeping: false,
	muted: false,
	mood: "idle",
	journal: [],
	tapStreak: 0,
	lastTapAt: 0,
	bumpAffection: (delta) => set({ affection: clamp(get().affection + delta, 0, 100) }),
	setMood: (mood) => set({ mood }),
	setSleeping: (value) => set({
		sleeping: value,
		mood: value ? "sleepy" : "idle"
	}),
	toggleMuted: () => set({ muted: !get().muted }),
	record: (kind) => {
		set({ journal: [{
			id: uid$1(),
			at: Date.now(),
			kind,
			note: journalNote(kind)
		}, ...get().journal].slice(0, MAX_JOURNAL) });
	},
	bumpStreak: () => {
		const now = Date.now();
		const next = now - get().lastTapAt < 900 ? get().tapStreak + 1 : 1;
		set({
			tapStreak: next,
			lastTapAt: now
		});
		return next;
	},
	resetStreak: () => set({ tapStreak: 0 })
}), {
	name: "gin-home-v1",
	partialize: (s) => ({
		affection: s.affection,
		muted: s.muted,
		journal: s.journal
	})
}));
var HIT_ZONES = [
	{
		id: "phone",
		label: "手机",
		left: .5,
		top: 30,
		width: 13,
		height: 30
	},
	{
		id: "head",
		label: "头发",
		left: 11,
		top: 3,
		width: 18,
		height: 38
	},
	{
		id: "cat",
		label: "猫",
		left: 21,
		top: 48,
		width: 23,
		height: 36
	},
	{
		id: "body",
		label: "后背",
		left: 30,
		top: 22,
		width: 28,
		height: 40
	},
	{
		id: "legs",
		label: "腿",
		left: 56,
		top: 30,
		width: 24,
		height: 36
	},
	{
		id: "feet",
		label: "脚",
		left: 79,
		top: 14,
		width: 20,
		height: 38
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var ACTIONS = [
	{
		id: "pet",
		label: "摸摸",
		Icon: Hand
	},
	{
		id: "feed",
		label: "投喂",
		Icon: CupSoda
	},
	{
		id: "talk",
		label: "说话",
		Icon: MessageCircle
	},
	{
		id: "nap",
		label: "小憩",
		Icon: Moon
	}
];
function ActionDock({ sleeping, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "相处",
		className: "pointer-events-auto mx-auto flex w-full max-w-md items-stretch gap-1 rounded-3xl bg-surface/90 p-1.5 shadow-[var(--shadow-border)] backdrop-blur-sm",
		children: ACTIONS.map(({ id, label, Icon }) => {
			const napActive = sleeping && id === "nap";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onAction(id),
				className: cn("flex min-h-12 flex-1 flex-col items-center justify-center gap-0.5 rounded-2xl px-2 py-2 text-muted", "transition-[background-color,color,scale] duration-150 ease-out", "hover:bg-bg hover:text-fg active:scale-[0.96]", napActive && "bg-bg text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-4",
					strokeWidth: 1.75,
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium tracking-wide",
					children: napActive ? "叫醒" : label
				})]
			}, id);
		})
	});
}
function JournalSheet({ open, affection, entries, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-40 flex items-end justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "关闭记录",
			className: "absolute inset-0 bg-ink/25",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			role: "dialog",
			"aria-labelledby": "journal-title",
			className: "relative mb-0 w-full max-w-lg rounded-t-[28px] bg-bg px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4 shadow-[var(--shadow-border)]",
			style: { animation: "sheet-in 250ms var(--ease-out-smooth) both" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-surface-2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "journal-title",
						className: "font-display text-xl font-medium",
						children: "今日"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"亲密度 ",
							affection,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-1.5 text-subtle",
								children: "·"
							}),
							affectionTitle(affection)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "关闭",
						className: "grid size-11 place-items-center rounded-full text-muted transition-[background-color,scale] duration-150 ease-out hover:bg-surface hover:text-fg active:scale-[0.96]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 max-h-[min(52vh,28rem)] space-y-1 overflow-y-auto pr-1",
					children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted",
						children: "还没发生什么。点他一下。"
					}) : entries.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex items-baseline justify-between gap-3 rounded-xl px-3 py-2.5", "bg-surface/70"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-fg",
							children: e.note
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
							className: "shrink-0 text-xs tabular-nums text-subtle",
							children: formatTime(e.at)
						})]
					}, e.id))
				})
			]
		})]
	});
}
function formatTime(at) {
	const d = new Date(at);
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function MilkProp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "milk-arc pointer-events-none absolute bottom-[20%] left-[14%] z-20 origin-bottom",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "52",
			height: "70",
			viewBox: "0 0 44 58",
			fill: "none",
			"aria-hidden": true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M10 16h24l3 38H7L10 16Z",
					className: "fill-bubble stroke-ink",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M10 16l2-8h20l2 8",
					className: "fill-surface-2 stroke-ink",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "16",
					y: "4",
					width: "12",
					height: "6",
					rx: "1.5",
					className: "fill-accent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "14",
					y: "24",
					width: "16",
					height: "16",
					rx: "2",
					className: "fill-heart"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "22",
					cy: "32",
					r: "4.2",
					className: "fill-bubble"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20.2 33.6c0-1.4.8-2.4 1.8-2.4s1.8 1 1.8 2.4",
					className: "stroke-heart",
					strokeWidth: "1.2",
					fill: "none"
				})
			]
		})
	});
}
function PawMark({ className, title, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": title ? void 0 : true,
		className: cn("block", className),
		style,
		children: [
			title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "7.2",
				cy: "8.2",
				r: "2.15"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11.6",
				cy: "6.1",
				r: "2.05"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16.2",
				cy: "7.6",
				r: "2.1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.4",
				cy: "11.8",
				r: "1.85"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "11.4",
				cy: "16.2",
				rx: "5.1",
				ry: "4.2"
			})
		]
	});
}
function Particles({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-30 overflow-hidden",
		children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute",
			style: {
				left: `${p.x}%`,
				top: `${p.y}%`,
				animation: `particle-float 980ms var(--ease-out-smooth) ${p.delay}ms both`,
				["--dx"]: `${p.id.charCodeAt(0) % 17 - 8}px`,
				["--spin"]: `${p.id.charCodeAt(3) % 24 - 12}deg`
			},
			children: p.kind === "heart" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartMark, { className: "size-5 text-heart" }) : p.kind === "z" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg font-medium text-muted",
				children: "Z"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PawMark, { className: "size-5 text-paw" })
		}, p.id))
	});
}
function HeartMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.1 20.3c-.3 0-.5-.1-1.6-1.1-3.3-2.9-6.5-5.6-6.5-9 0-2.4 1.9-4.3 4.3-4.3 1.4 0 2.7.7 3.8 1.9 1.1-1.2 2.4-1.9 3.8-1.9 2.4 0 4.3 1.9 4.3 4.3 0 3.4-3.2 6.1-6.5 9-1.1 1-1.3 1.1-1.6 1.1Z" })
	});
}
function SpeechBubble({ speech, leaving }) {
	const isCat = speech.from === "cat";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute z-20 max-w-[min(16rem,70vw)]", leaving ? "speech-leave" : "speech-enter"),
		style: {
			left: `${speech.x}%`,
			top: `${speech.y}%`,
			transform: "translate(-30%, -110%)"
		},
		role: "status",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative rounded-2xl px-3.5 py-2.5 text-sm leading-snug shadow-[var(--shadow-border)]", isCat ? "bg-surface-2 text-muted" : "bg-bubble text-fg"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("font-medium", isCat && "text-xs tracking-wide"),
				children: speech.text
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("absolute -bottom-1.5 left-6 size-3 rotate-45 rounded-sm", isCat ? "bg-surface-2" : "bg-bubble"),
				"aria-hidden": true
			})]
		})
	});
}
function TopBar({ timeLabel, mood, sleeping, affection, muted, onToggleMute, onOpenJournal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none flex items-start justify-between gap-4 px-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-medium leading-none tracking-tight text-fg",
					children: "银"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1.5 text-xs font-medium tracking-wide text-muted",
					children: [
						moodLabel(mood, sleeping),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-1.5 text-subtle",
							children: "·"
						}),
						affectionTitle(affection)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2.5 h-0.5 w-28 overflow-hidden rounded-full bg-surface-2",
					"aria-label": `亲密度 ${affection}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-accent transition-[width] duration-500 ease-[var(--ease-out-smooth)]",
						style: { width: `${affection}%` }
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mr-1 font-display text-sm tabular-nums text-muted",
					children: timeLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
					label: muted ? "打开声音" : "关闭声音",
					onClick: onToggleMute,
					children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
					label: "今日记录",
					onClick: onOpenJournal,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" })
				})
			]
		})]
	});
}
function IconBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: cn("grid size-11 place-items-center rounded-full text-muted", "transition-[background-color,color,scale] duration-150 ease-out", "hover:bg-surface hover:text-fg active:scale-[0.96]"),
		children
	});
}
function formatHm(d) {
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function zoneAt(xPct, yPct) {
	return HIT_ZONES.find((z) => xPct >= z.left && xPct <= z.left + z.width && yPct >= z.top && yPct <= z.top + z.height)?.id ?? "body";
}
function speechAnchor(zone, from) {
	if (from === "cat" || zone === "cat") return {
		x: 36,
		y: 50
	};
	if (zone === "feet") return {
		x: 72,
		y: 20
	};
	if (zone === "legs") return {
		x: 58,
		y: 26
	};
	if (zone === "phone") return {
		x: 16,
		y: 20
	};
	return {
		x: 22,
		y: 16
	};
}
function CompanionStage() {
	const affection = useGinStore((s) => s.affection);
	const sleeping = useGinStore((s) => s.sleeping);
	const muted = useGinStore((s) => s.muted);
	const mood = useGinStore((s) => s.mood);
	const journal = useGinStore((s) => s.journal);
	const bumpAffection = useGinStore((s) => s.bumpAffection);
	const setMood = useGinStore((s) => s.setMood);
	const setSleeping = useGinStore((s) => s.setSleeping);
	const toggleMuted = useGinStore((s) => s.toggleMuted);
	const record = useGinStore((s) => s.record);
	const bumpStreak = useGinStore((s) => s.bumpStreak);
	const figureRef = (0, import_react.useRef)(null);
	const greeted = (0, import_react.useRef)(false);
	const idleTimer = (0, import_react.useRef)(null);
	const [pose, setPose] = (0, import_react.useState)("idle");
	const [origin, setOrigin] = (0, import_react.useState)("44% 82%");
	const [speech, setSpeech] = (0, import_react.useState)(null);
	const [leaving, setLeaving] = (0, import_react.useState)(false);
	const [particles, setParticles] = (0, import_react.useState)([]);
	const [showMilk, setShowMilk] = (0, import_react.useState)(false);
	const [hint, setHint] = (0, import_react.useState)(true);
	const [journalOpen, setJournalOpen] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(null);
	const [blush, setBlush] = (0, import_react.useState)(false);
	const timeLabel = now ? formatHm(now) : "--:--";
	const speak = (0, import_react.useCallback)((text, from, zone = "head") => {
		const anchor = speechAnchor(zone, from);
		setLeaving(false);
		setSpeech({
			id: uid(),
			text,
			from,
			x: anchor.x,
			y: anchor.y
		});
	}, []);
	const burst = (0, import_react.useCallback)((kind, x, y, count = 3) => {
		const next = Array.from({ length: count }, (_, i) => ({
			id: uid() + i,
			kind,
			x: x + (Math.random() * 8 - 4),
			y: y + (Math.random() * 6 - 3),
			delay: i * 70
		}));
		setParticles((prev) => [...prev, ...next]);
		window.setTimeout(() => {
			setParticles((prev) => prev.filter((p) => !next.some((n) => n.id === p.id)));
		}, 1100);
	}, []);
	const poke = (0, import_react.useCallback)(() => {
		setPose("react");
		window.setTimeout(() => setPose("idle"), 620);
	}, []);
	const resetIdle = (0, import_react.useCallback)(() => {
		if (idleTimer.current) window.clearTimeout(idleTimer.current);
		idleTimer.current = window.setTimeout(() => {
			if (useGinStore.getState().sleeping) return;
			speak(lineForIdle(), "gin", "head");
		}, 18e3);
	}, [speak]);
	const log = (0, import_react.useCallback)((kind) => {
		setHint(false);
		resetIdle();
		record(kind);
	}, [record, resetIdle]);
	const onFigurePointer = (0, import_react.useCallback)((clientX, clientY) => {
		const el = figureRef.current;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const xPct = (clientX - rect.left) / rect.width * 100;
		const yPct = (clientY - rect.top) / rect.height * 100;
		setOrigin(`${xPct}% ${yPct}%`);
		const state = useGinStore.getState();
		if (state.sleeping) {
			if (!state.muted) playWake();
			setSleeping(false);
			speak(lineForWake(), "gin", "head");
			burst("paw", xPct, yPct, 2);
			poke();
			log("wake");
			return;
		}
		const zone = zoneAt(xPct, yPct);
		const annoyed = bumpStreak() >= 5;
		const line = annoyed ? {
			text: lineForAnnoyed(),
			from: "gin"
		} : lineForZone(zone);
		if (!state.muted) {
			if (zone === "cat") playCat();
			else playTap();
		}
		speak(line.text, line.from, zone);
		poke();
		burst(zone === "cat" ? "paw" : annoyed ? "paw" : "heart", xPct, yPct, annoyed ? 2 : 3);
		bumpAffection(annoyed ? 0 : zone === "cat" ? 2 : 1);
		setMood(annoyed ? "annoyed" : zone === "cat" ? "happy" : "idle");
		setBlush(zone === "head" || zone === "body");
		window.setTimeout(() => setBlush(false), 900);
		log(zone);
	}, [
		bumpAffection,
		bumpStreak,
		burst,
		log,
		poke,
		setMood,
		setSleeping,
		speak
	]);
	const onAction = (0, import_react.useCallback)((id) => {
		unlockAudio();
		const state = useGinStore.getState();
		if (id === "nap") {
			if (state.sleeping) {
				if (!state.muted) playWake();
				setSleeping(false);
				speak(lineForWake(), "gin", "head");
				log("wake");
				poke();
				return;
			}
			if (!state.muted) playSleep();
			setSleeping(true);
			speak(lineForAction("nap"), "gin", "head");
			burst("z", 28, 16, 3);
			log("nap");
			return;
		}
		if (state.sleeping) {
			if (!state.muted) playWake();
			setSleeping(false);
			speak(lineForWake(), "gin", "head");
			log("wake");
		}
		if (id === "pet") {
			if (!useGinStore.getState().muted) playPet();
			speak(lineForAction("pet"), "gin", "head");
			poke();
			burst("heart", 26, 22, 5);
			bumpAffection(2);
			setMood("happy");
			setBlush(true);
			window.setTimeout(() => setBlush(false), 1100);
			log("pet");
			return;
		}
		if (id === "feed") {
			if (!useGinStore.getState().muted) playFeed();
			setShowMilk(true);
			setPose("eating");
			setMood("eating");
			speak(lineForAction("feed"), "gin", "phone");
			bumpAffection(3);
			window.setTimeout(() => {
				setShowMilk(false);
				setPose("idle");
				setMood("happy");
			}, 1e3);
			log("feed");
			return;
		}
		speak(lineForAction("talk"), "gin", "head");
		poke();
		bumpAffection(1);
		setMood("idle");
		log("talk");
	}, [
		bumpAffection,
		burst,
		log,
		poke,
		setMood,
		setSleeping,
		speak
	]);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const tick = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 3e4);
		return () => window.clearInterval(tick);
	}, []);
	(0, import_react.useEffect)(() => {
		if (greeted.current) return;
		greeted.current = true;
		const hour = (/* @__PURE__ */ new Date()).getHours();
		const t = window.setTimeout(() => {
			if (useGinStore.getState().sleeping) return;
			speak(greetingForHour(hour), "gin", "head");
		}, 700);
		resetIdle();
		return () => {
			window.clearTimeout(t);
			if (idleTimer.current) window.clearTimeout(idleTimer.current);
		};
	}, [resetIdle, speak]);
	(0, import_react.useEffect)(() => {
		if (!speech) return;
		const t = window.setTimeout(() => setLeaving(true), 2400);
		const t2 = window.setTimeout(() => {
			setSpeech(null);
			setLeaving(false);
		}, 2580);
		return () => {
			window.clearTimeout(t);
			window.clearTimeout(t2);
		};
	}, [speech]);
	const hour = now?.getHours() ?? 12;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-[100dvh] flex-col overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 transition-opacity duration-700 ease-[var(--ease-out-smooth)]",
				style: {
					opacity: sleeping || hour >= 22 || hour < 6 ? 1 : 0,
					background: "linear-gradient(180deg, color-mix(in oklab, var(--color-ink) 10%, var(--color-dusk)) 0%, var(--color-bg-warm) 100%)"
				},
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmbientPaws, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-[100dvh] flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
						timeLabel,
						mood,
						sleeping,
						affection,
						muted,
						onToggleMute: () => {
							unlockAudio();
							toggleMuted();
						},
						onOpenJournal: () => setJournalOpen(true)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative flex min-h-0 flex-1 flex-col items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full max-w-5xl overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									ref: figureRef,
									className: cn("gin-figure relative mx-auto select-none", sleeping && "is-sleeping", pose === "react" && "is-reacting", pose === "eating" && "is-eating"),
									style: { transformOrigin: origin },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "银，点一下他会理你",
											className: "block w-full cursor-pointer touch-manipulation border-0 bg-transparent p-0",
											onPointerDown: (e) => {
												if (e.button !== 0 && e.pointerType === "mouse") return;
												onFigurePointer(e.clientX, e.clientY);
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: "/gin.webp",
												alt: "银趴在那里看手机，一只狸花猫靠在他手臂上",
												draggable: false,
												className: "ml-0 h-auto w-[min(178vw,72rem)] max-w-none max-h-[min(56vh,520px)] object-contain object-left sm:mx-auto sm:w-full sm:max-w-full sm:max-h-[min(68vh,720px)] sm:object-center"
											})
										}),
										blush && !sleeping ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pointer-events-none absolute inset-0",
											"aria-hidden": true,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-[30%] left-[17%] size-8 rounded-full bg-heart/45 blur-[7px] sm:size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-[31%] left-[23%] size-7 rounded-full bg-heart/30 blur-[7px] sm:size-9" })]
										}) : null,
										sleeping ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "z-rise pointer-events-none absolute top-[8%] left-[26%] font-display text-xl text-muted",
											children: "Z"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "z-rise pointer-events-none absolute top-[4%] left-[31%] font-display text-lg text-subtle",
											style: { animationDelay: "0.6s" },
											children: "z"
										})] }) : null,
										showMilk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MilkProp, {}) : null,
										speech ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeechBubble, {
											speech,
											leaving
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Particles, { items: particles })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "gin-shadow mx-auto -mt-2 h-5 w-[70%] max-w-xl rounded-[100%] bg-ink/20 blur-md",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-5 h-5 text-center text-sm text-muted", hint ? "hint-pulse" : "invisible"),
									children: "点一点他"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 mt-2 w-full pb-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionDock, {
							sleeping,
							onAction
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalSheet, {
				open: journalOpen,
				affection,
				entries: journal,
				onClose: () => setJournalOpen(false)
			})
		]
	});
}
function AmbientPaws() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": true,
		children: [
			{
				top: "18%",
				left: "72%",
				size: 28,
				delay: "0s"
			},
			{
				top: "32%",
				left: "82%",
				size: 22,
				delay: "1.4s"
			},
			{
				top: "48%",
				left: "76%",
				size: 18,
				delay: "2.6s"
			},
			{
				top: "22%",
				left: "8%",
				size: 16,
				delay: "3.2s"
			}
		].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PawMark, {
			className: "paw-drift absolute text-paw",
			style: {
				top: s.top,
				left: s.left,
				width: s.size,
				height: s.size,
				animationDelay: s.delay
			}
		}, i))
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanionStage, {});
}
//#endregion
export { Home as component };
